import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TriangleTypeStructuralTest {

	@Before
	public void setUp() throws Exception {
	}

	// Iftekhar: This is a dummy test case, which you can replace.
	@Test
	public void testTriangleType() {
		
		TriangleType x = new TriangleType();
		
		assertEquals(4, TriangleType.triangleType(-5,1,1));
		assertEquals(4, TriangleType.triangleType(0,-1,1));
		assertEquals(4, TriangleType.triangleType(0,1,-1));
		assertEquals(4, TriangleType.triangleType(0,1,1));
		assertEquals(4, TriangleType.triangleType(-1,-1,-1));
		assertEquals(5, TriangleType.triangleType(1001,1001,1001));
		assertEquals(4, TriangleType.triangleType(0,0,0));
		assertEquals(4, TriangleType.triangleType(1,995,88));
		assertEquals(4, TriangleType.triangleType(100,500,900));
		assertEquals(1, TriangleType.triangleType(500,600,700));
		assertEquals(4, TriangleType.triangleType(-1,1100,9));
		assertEquals(2, TriangleType.triangleType(995,995,1000));
		assertEquals(1, TriangleType.triangleType(3,5,7));
		assertEquals(4, TriangleType.triangleType(-995,-995,-1000));
		assertEquals(5, TriangleType.triangleType(1001,1001,2000));
		assertEquals(4, TriangleType.triangleType(5,85,5));
		assertEquals(4, TriangleType.triangleType(-5,-85,-5));
		assertEquals(2, TriangleType.triangleType(1,5,5));
		assertEquals(4, TriangleType.triangleType(1,5,3));
		assertEquals(4, TriangleType.triangleType(10,5,3));
		assertEquals(5, TriangleType.triangleType(1001,5,6));
		assertEquals(5, TriangleType.triangleType(101,1005,6));
		assertEquals(4, TriangleType.triangleType(101,105,1000));
		assertEquals(2, TriangleType.triangleType(13,20,13));
		assertEquals(5, TriangleType.triangleType(100000,2,55555));
		assertEquals(1, TriangleType.triangleType(2,3,4));
		assertEquals(3, TriangleType.triangleType(7,7,7));
		assertEquals(4, TriangleType.triangleType(0,-1,-1));
		assertEquals(4, TriangleType.triangleType(-1,1,-1));
		assertEquals(4, TriangleType.triangleType(-1,-1,1));
	}

}
